# React Router Demo Sandbox

An example of React Router 5.x . Initially based on https://codesandbox.io/p/sandbox/react-router-basic-forked-dgsxym .
